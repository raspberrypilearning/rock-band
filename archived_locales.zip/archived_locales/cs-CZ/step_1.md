Toto je starší verze **Rocková skupina**. V této chvíli neobsahuje nejnovější obsah ani uživatelsky přívětivé funkce webu projektů. Před archivací bude tento projekt dočasně k dispozici ve starém formátu [zde](images/Rock Band.pdf). 

Potřebujeme vaši pomoc při aktualizaci a překladu projektů! Pokud nám chcete pomoci, prosím [dejte nám vědět](https://rpf.io/translators).
